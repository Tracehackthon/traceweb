import crypto from 'node:crypto';
import {enqueueSensemakingJob, ensureHostWorkflowSchema} from './host-workflow.mjs';
import {scopeContractFromFindingRow, validateScopeContract, upcastLegacyScope} from './scope-contract.mjs';

/**
 * The Codex host stream is deliberately stored beside Product Workspace, not
 * in a project `.trace` ledger or in the optional Agent runtime database.
 * These tables are append-only at the event/receipt boundary; the session and
 * turn rows are the small current-state indexes used to answer the next hook.
 */
export const HOST_SESSION_TABLES = Object.freeze([
  'host_sessions',
  'host_turns',
  'host_ingest_events',
  'host_control_commands',
  'workflow_findings',
]);

export const HOST_SESSION_STATUSES = Object.freeze(['attached', 'paused', 'ended']);
export const HOST_TURN_STATES = Object.freeze(['started', 'completed', 'interrupted']);
export const HOST_EVENT_KINDS = Object.freeze([
  'SessionStart',
  'UserPromptSubmit',
  'PreToolUse',
  'PostToolUse',
  'Stop',
  'Interrupt',
  'SessionEnd',
]);

const MAX_ID = 512;
const MAX_HOST = 128;
const MAX_TEXT = 1_000_000;
const CONTROL_OPERATIONS = new Set(['attach', 'pause', 'detach', 'finding']);
const EVENT_KINDS = new Set(HOST_EVENT_KINDS);
const TURN_STATES = new Set(HOST_TURN_STATES);
const SESSION_STATUSES = new Set(HOST_SESSION_STATUSES);
const FORBIDDEN_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

export class HostIngestError extends Error {
  constructor(status, code, message) {
    super(message);
    this.name = 'HostIngestError';
    this.status = status;
    this.code = code;
  }
}

function fail(code, message, status = 422) {
  throw new HostIngestError(status, code, message);
}

function plain(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function validText(value, field, max = MAX_TEXT, {empty = false} = {}) {
  // Prompt and assistant messages are allowed to contain normal newlines and
  // tabs. NUL/DEL are rejected because they make receipts and diagnostics
  // ambiguous; identity validation below remains stricter and rejects all
  // control characters.
  if (typeof value !== 'string' || value.length > max || /[\x00\x7f]/.test(value) || (!empty && value.trim().length === 0)) {
    fail('INVALID_HOST_EVENT', `${field} must be a valid text value`);
  }
  return value;
}

function optionalText(value, field, max = MAX_TEXT) {
  if (value === undefined || value === null) return null;
  return validText(value, field, max, {empty: true});
}

function identity(value, field, max = MAX_ID) {
  if (typeof value !== 'string' || value.length === 0 || value.length > max || /[\x00-\x1f\x7f]/.test(value) || FORBIDDEN_KEYS.has(value)) {
    fail('INVALID_HOST_IDENTITY', `${field} must be a usable host identity`);
  }
  return value;
}

function optionalIdentity(value, field, max = MAX_ID) {
  if (value === undefined || value === null || value === '') return null;
  return identity(value, field, max);
}

function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (plain(value)) return Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])]));
  return value;
}

export function stableHostJson(value) {
  return JSON.stringify(canonical(value));
}

function sha(value) {
  return crypto.createHash('sha256').update(value, 'utf8').digest('hex');
}

function boundedBodyHash(value, field) {
  let encoded;
  try { encoded = stableHostJson(value); } catch { fail('INVALID_HOST_EVENT', `${field} must be JSON serializable`); }
  if (typeof encoded !== 'string' || encoded.length > MAX_TEXT) fail('INVALID_HOST_EVENT', `${field} exceeds the bounded host event size`);
  return sha(encoded);
}

function now() {
  return new Date().toISOString();
}

function tableColumns(db, table) {
  return new Set(db.prepare(`PRAGMA table_info(${table})`).all().map(row => row.name));
}

function requireColumns(db, table, columns) {
  const actual = tableColumns(db, table);
  if (columns.some(column => !actual.has(column))) fail('STORAGE_CORRUPT', `Host ingest table ${table} is missing a required column`, 503);
}

/** Create or validate only the host-ingest extension of the web database. */
export function ensureHostSessionSchema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS host_sessions(
      host TEXT NOT NULL,
      session_id TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('attached','paused','ended')),
      capture_policy TEXT NOT NULL CHECK(capture_policy='explicit'),
      project_ref TEXT,
      created_at TEXT NOT NULL,
      attached_at TEXT NOT NULL,
      paused_at TEXT,
      ended_at TEXT,
      updated_at TEXT NOT NULL,
      last_event_at TEXT,
      PRIMARY KEY(host, session_id)
    );
    CREATE TABLE IF NOT EXISTS host_turns(
      host TEXT NOT NULL,
      session_id TEXT NOT NULL,
      turn_id TEXT NOT NULL,
      state TEXT NOT NULL CHECK(state IN ('started','completed','interrupted')),
      prompt TEXT NOT NULL,
      last_assistant_message TEXT,
      started_at TEXT NOT NULL,
      completed_at TEXT,
      interrupted_at TEXT,
      updated_at TEXT NOT NULL,
      PRIMARY KEY(host, session_id, turn_id),
      FOREIGN KEY(host, session_id) REFERENCES host_sessions(host, session_id) ON DELETE RESTRICT
    );
    CREATE INDEX IF NOT EXISTS host_turns_recent_idx ON host_turns(host, session_id, updated_at);
    CREATE TABLE IF NOT EXISTS host_ingest_events(
      event_key TEXT PRIMARY KEY,
      host TEXT NOT NULL,
      session_id TEXT NOT NULL,
      turn_id TEXT,
      event_kind TEXT NOT NULL,
      tool_use_id TEXT,
      content_sha256 TEXT NOT NULL,
      event_json TEXT NOT NULL,
      outcome TEXT NOT NULL CHECK(outcome IN ('applied','ignored')),
      result_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS host_ingest_events_session_idx ON host_ingest_events(host, session_id, created_at);
    CREATE TABLE IF NOT EXISTS host_control_commands(
      command_id TEXT PRIMARY KEY,
      operation TEXT NOT NULL CHECK(operation IN ('attach','pause','detach','finding')),
      host TEXT NOT NULL,
      session_id TEXT NOT NULL,
      request_sha256 TEXT NOT NULL,
      result_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS workflow_findings(
      finding_id TEXT PRIMARY KEY,
      host TEXT NOT NULL,
      session_id TEXT NOT NULL,
      turn_id TEXT NOT NULL,
      observation TEXT NOT NULL,
      desired_behavior TEXT,
      scope TEXT NOT NULL CHECK(scope='unknown'),
      target_kind TEXT NOT NULL CHECK(target_kind='unresolved'),
      status TEXT NOT NULL CHECK(status='captured'),
      source_event_key TEXT,
      created_at TEXT NOT NULL,
      finding_kind TEXT NOT NULL DEFAULT 'captured',
      origin TEXT NOT NULL DEFAULT 'explicit',
      source_refs TEXT NOT NULL DEFAULT '[]',
      run_id TEXT,
      input_hash TEXT,
      result_hash TEXT,
      target_hint TEXT,
      FOREIGN KEY(host, session_id, turn_id) REFERENCES host_turns(host, session_id, turn_id) ON DELETE RESTRICT
    );
    CREATE INDEX IF NOT EXISTS workflow_findings_session_idx ON workflow_findings(host, session_id, created_at);
  `);
  requireColumns(db, 'host_sessions', ['host', 'session_id', 'status', 'capture_policy', 'project_ref', 'created_at', 'attached_at', 'paused_at', 'ended_at', 'updated_at', 'last_event_at']);
  requireColumns(db, 'host_turns', ['host', 'session_id', 'turn_id', 'state', 'prompt', 'last_assistant_message', 'started_at', 'completed_at', 'interrupted_at', 'updated_at']);
  requireColumns(db, 'host_ingest_events', ['event_key', 'host', 'session_id', 'turn_id', 'event_kind', 'tool_use_id', 'content_sha256', 'event_json', 'outcome', 'result_json', 'created_at']);
  requireColumns(db, 'host_control_commands', ['command_id', 'operation', 'host', 'session_id', 'request_sha256', 'result_json', 'created_at']);
  requireColumns(db, 'workflow_findings', ['finding_id', 'host', 'session_id', 'turn_id', 'observation', 'desired_behavior', 'scope', 'target_kind', 'status', 'source_event_key', 'created_at']);
  ensureHostWorkflowSchema(db);
}

function sessionView(row) {
  if (!row) return null;
  return {
    host: row.host,
    session_id: row.session_id,
    status: row.status,
    capture_policy: row.capture_policy,
    project_ref: row.project_ref ?? null,
    created_at: row.created_at,
    attached_at: row.attached_at,
    paused_at: row.paused_at ?? null,
    ended_at: row.ended_at ?? null,
    updated_at: row.updated_at,
    last_event_at: row.last_event_at ?? null,
  };
}

function turnView(row) {
  if (!row) return null;
  return {
    host: row.host,
    session_id: row.session_id,
    turn_id: row.turn_id,
    state: row.state,
    prompt: row.prompt,
    last_assistant_message: row.last_assistant_message ?? null,
    started_at: row.started_at,
    completed_at: row.completed_at ?? null,
    interrupted_at: row.interrupted_at ?? null,
    updated_at: row.updated_at,
  };
}

function findingView(row) {
  const scopeContract = scopeContractFromFindingRow(row, {project_ref: row.attached_project_ref ?? null});
  return {
    finding_id: row.finding_id,
    host: row.host,
    session_id: row.session_id,
    turn_id: row.turn_id,
    observation: row.observation,
    desired_behavior: row.desired_behavior ?? null,
    desiredBehavior: row.desired_behavior ?? null,
    scope: row.scope,
    target_kind: row.target_kind,
    targetKind: row.target_kind,
    status: row.status,
    finding_kind: row.finding_kind ?? 'captured',
    origin: row.origin ?? 'explicit',
    source_refs: (() => { try { return JSON.parse(row.source_refs ?? '[]'); } catch { return []; } })(),
    run_id: row.run_id ?? null,
    input_hash: row.input_hash ?? null,
    result_hash: row.result_hash ?? null,
    target_hint: row.target_hint ?? null,
    source_event_key: row.source_event_key ?? null,
    created_at: row.created_at,
    scope_contract: scopeContract,
    scopeContract,
  };
}

function eventIdentity(input) {
  if (!plain(input)) fail('INVALID_HOST_EVENT', 'Host event must be a JSON object', 400);
  const host = identity(input.host ?? 'codex', 'host', MAX_HOST);
  const sessionId = identity(input.session_id ?? input.sessionId, 'session_id');
  const eventKind = input.event_kind ?? input.eventKind ?? input.hook_event_name ?? input.hookEventName;
  if (!EVENT_KINDS.has(eventKind)) fail('INVALID_HOST_EVENT', `Unsupported host event: ${String(eventKind)}`);
  const turnId = optionalIdentity(input.turn_id ?? input.turnId, 'turn_id');
  const toolUseId = optionalIdentity(input.tool_use_id ?? input.toolUseId, 'tool_use_id');
  if ((eventKind === 'SessionStart' || eventKind === 'SessionEnd') && toolUseId !== null) fail('INVALID_HOST_EVENT', `${eventKind} does not accept tool_use_id`);
  const eventKey = [host, sessionId, turnId ?? '', eventKind, toolUseId ?? ''].join('\u001f');
  return {host, sessionId, eventKind, turnId, toolUseId, eventKey};
}

/** Normalize only official hook fields. Arbitrary fields never enter web.sqlite. */
function normalizedEvent(input, identityValue) {
  const {eventKind} = identityValue;
  const result = {event_kind: eventKind};
  // Keep a missing prompt distinguishable from an explicitly empty prompt so
  // an attached session cannot create a started turn without the official
  // UserPromptSubmit payload. Unattached/paused events are still no-ops and
  // therefore do not need to persist or reject a missing body.
  const prompt = input.prompt;
  const lastAssistantMessage = input.last_assistant_message ?? input.lastAssistantMessage;
  const toolInput = input.tool_input ?? input.toolInput;
  const toolResponse = input.tool_response ?? input.toolResponse;
  if (eventKind === 'UserPromptSubmit') result.prompt = prompt === undefined ? null : validText(prompt, 'prompt', MAX_TEXT, {empty: true});
  if (eventKind === 'Stop') result.last_assistant_message = optionalText(lastAssistantMessage, 'last_assistant_message');
  if (eventKind === 'PreToolUse' && toolInput !== undefined) result.tool_input_sha256 = boundedBodyHash(toolInput, 'tool_input');
  if (eventKind === 'PostToolUse' && toolResponse !== undefined) result.tool_response_sha256 = boundedBodyHash(toolResponse, 'tool_response');
  // Event metadata is intentionally bounded and does not include cwd or tool bodies.
  return result;
}

function eventResult({identityValue, session, outcome, reason, turn, capturedFields = [], extra = {}}) {
  const result = {
    status: outcome === 'applied' ? 'captured' : 'ignored',
    outcome,
    event_key: identityValue.eventKey,
    event_kind: identityValue.eventKind,
    host: identityValue.host,
    session_id: identityValue.sessionId,
    turn_id: identityValue.turnId,
    session_status: session?.status ?? null,
  };
  if (reason !== undefined) result.reason = reason;
  if (turn !== undefined) result.turn = turn;
  if (capturedFields.length > 0) result.captured_fields = capturedFields;
  Object.assign(result, extra);
  // Return the same canonical property order that is persisted. This makes a
  // retry byte-for-byte JSON stable, not merely deep-equal after parsing.
  return JSON.parse(stableHostJson(result));
}

function commandIdentity(input, operation) {
  if (!plain(input)) fail('INVALID_HOST_COMMAND', 'Host control request must be an object', 400);
  const commandId = identity(input.command_id ?? input.commandId, 'command_id');
  const host = identity(input.host ?? 'codex', 'host', MAX_HOST);
  const sessionId = identity(input.session_id ?? input.sessionId, 'session_id');
  if (!CONTROL_OPERATIONS.has(operation)) fail('INVALID_HOST_COMMAND', `Unsupported host control operation: ${operation}`);
  return {commandId, host, sessionId};
}

function commandResult(status, identityValue, extra = {}) {
  return {status, operation: extra.operation, command_id: identityValue.commandId, host: identityValue.host, session_id: identityValue.sessionId, ...extra};
}

function readSession(db, host, sessionId) {
  return db.prepare('SELECT * FROM host_sessions WHERE host=? AND session_id=?').get(host, sessionId);
}

function readTurn(db, host, sessionId, turnId) {
  return db.prepare('SELECT * FROM host_turns WHERE host=? AND session_id=? AND turn_id=?').get(host, sessionId, turnId);
}

function checkSessionState(session, {allowPaused = false, operation = 'capture'}) {
  if (!session) return false;
  if (session.status === 'ended') fail('HOST_SESSION_ENDED', `Host session has ended; ${operation} cannot revive it`, 409);
  if (session.status === 'paused' && !allowPaused) return false;
  return true;
}

function insertEvent(db, identityValue, normalized, outcome, result, timestamp) {
  const eventJson = stableHostJson(normalized);
  const contentSha = sha(eventJson);
  db.prepare(`INSERT INTO host_ingest_events
    (event_key,host,session_id,turn_id,event_kind,tool_use_id,content_sha256,event_json,outcome,result_json,created_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(
    identityValue.eventKey,
    identityValue.host,
    identityValue.sessionId,
    identityValue.turnId,
    identityValue.eventKind,
    identityValue.toolUseId,
    contentSha,
    eventJson,
    outcome,
    stableHostJson(result),
    timestamp,
  );
  return {contentSha, eventJson};
}

function duplicateEvent(db, identityValue, normalized) {
  const existing = db.prepare('SELECT content_sha256,result_json FROM host_ingest_events WHERE event_key=?').get(identityValue.eventKey);
  if (!existing) return null;
  const contentSha = sha(stableHostJson(normalized));
  if (existing.content_sha256 !== contentSha) fail('HOST_EVENT_CONFLICT', 'The same host event idempotency key was replayed with different content', 409);
  try { return JSON.parse(existing.result_json); } catch { fail('STORAGE_CORRUPT', 'Host event receipt is not valid JSON', 503); }
}

function controlReplay(db, commandId, fingerprint) {
  const existing = db.prepare('SELECT request_sha256,result_json FROM host_control_commands WHERE command_id=?').get(commandId);
  if (!existing) return null;
  if (existing.request_sha256 !== fingerprint) fail('HOST_COMMAND_CONFLICT', 'The same host command ID was replayed with different content', 409);
  try { return JSON.parse(existing.result_json); } catch { fail('STORAGE_CORRUPT', 'Host command receipt is not valid JSON', 503); }
}

function saveControl(db, identityValue, operation, fingerprint, result, timestamp) {
  const canonicalResult = JSON.parse(stableHostJson(result));
  db.prepare(`INSERT INTO host_control_commands(command_id,operation,host,session_id,request_sha256,result_json,created_at)
    VALUES(?,?,?,?,?,?,?)`).run(identityValue.commandId, operation, identityValue.host, identityValue.sessionId, fingerprint, stableHostJson(canonicalResult), timestamp);
  return canonicalResult;
}

/**
 * Create the user-level host ingest service over an existing Product Workspace
 * DatabaseSync handle. `transaction` must run its callback under the same
 * SQLite write transaction as the web workspace owner.
 */
export function createHostSessionIngest({db, transaction}) {
  if (!db || typeof db.prepare !== 'function' || typeof transaction !== 'function') throw new TypeError('createHostSessionIngest requires db and transaction');
  ensureHostSessionSchema(db);

  function attach(input) {
    const identityValue = commandIdentity(input, 'attach');
    const projectRef = optionalText(input.project_ref ?? input.projectRef, 'project_ref', MAX_ID * 8);
    const fingerprint = sha(stableHostJson({operation: 'attach', host: identityValue.host, session_id: identityValue.sessionId, project_ref: projectRef}));
    return transaction(() => {
      const replay = controlReplay(db, identityValue.commandId, fingerprint);
      if (replay) return replay;
      const timestamp = now();
      const previous = readSession(db, identityValue.host, identityValue.sessionId);
      if (previous?.status === 'ended') fail('HOST_SESSION_ENDED', 'An ended host session cannot be re-attached; use a new session identity', 409);
      if (previous && previous.project_ref !== null && projectRef !== null && previous.project_ref !== projectRef) fail('HOST_SESSION_BINDING_CONFLICT', 'Host session is already bound to a different project', 409);
      if (!previous) {
        db.prepare(`INSERT INTO host_sessions(host,session_id,status,capture_policy,project_ref,created_at,attached_at,paused_at,ended_at,updated_at,last_event_at)
          VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(identityValue.host, identityValue.sessionId, 'attached', 'explicit', projectRef, timestamp, timestamp, null, null, timestamp, null);
      } else {
        db.prepare(`UPDATE host_sessions SET status='attached', project_ref=COALESCE(project_ref,?), attached_at=?, paused_at=NULL, updated_at=?
          WHERE host=? AND session_id=?`).run(projectRef, timestamp, timestamp, identityValue.host, identityValue.sessionId);
      }
      const session = sessionView(readSession(db, identityValue.host, identityValue.sessionId));
      return saveControl(db, identityValue, 'attach', fingerprint, commandResult('attached', identityValue, {operation: 'attach', session}), timestamp);
    });
  }

  function pause(input) {
    const identityValue = commandIdentity(input, 'pause');
    const fingerprint = sha(stableHostJson({operation: 'pause', host: identityValue.host, session_id: identityValue.sessionId}));
    return transaction(() => {
      const replay = controlReplay(db, identityValue.commandId, fingerprint);
      if (replay) return replay;
      const timestamp = now();
      const previous = readSession(db, identityValue.host, identityValue.sessionId);
      if (!previous) fail('HOST_SESSION_NOT_FOUND', 'Host session is not attached', 404);
      if (previous.status === 'ended') fail('HOST_SESSION_ENDED', 'An ended host session cannot be paused', 409);
      if (previous.status === 'attached') db.prepare(`UPDATE host_sessions SET status='paused', paused_at=?, updated_at=? WHERE host=? AND session_id=?`).run(timestamp, timestamp, identityValue.host, identityValue.sessionId);
      const session = sessionView(readSession(db, identityValue.host, identityValue.sessionId));
      return saveControl(db, identityValue, 'pause', fingerprint, commandResult('paused', identityValue, {operation: 'pause', session}), timestamp);
    });
  }

  function detach(input) {
    const identityValue = commandIdentity(input, 'detach');
    const fingerprint = sha(stableHostJson({operation: 'detach', host: identityValue.host, session_id: identityValue.sessionId}));
    return transaction(() => {
      const replay = controlReplay(db, identityValue.commandId, fingerprint);
      if (replay) return replay;
      const timestamp = now();
      const previous = readSession(db, identityValue.host, identityValue.sessionId);
      if (!previous) fail('HOST_SESSION_NOT_FOUND', 'Host session is not attached', 404);
      if (previous.status !== 'ended') {
        db.prepare(`UPDATE host_sessions SET status='ended', ended_at=?, updated_at=? WHERE host=? AND session_id=?`).run(timestamp, timestamp, identityValue.host, identityValue.sessionId);
        // Closing a session is also the deterministic boundary for a turn
        // whose Stop/Interrupt event never arrived.
        db.prepare(`UPDATE host_turns SET state='interrupted', interrupted_at=?, updated_at=?
          WHERE host=? AND session_id=? AND state='started'`).run(timestamp, timestamp, identityValue.host, identityValue.sessionId);
      }
      const session = sessionView(readSession(db, identityValue.host, identityValue.sessionId));
      return saveControl(db, identityValue, 'detach', fingerprint, commandResult('ended', identityValue, {operation: 'detach', session}), timestamp);
    });
  }

  function ingestEvent(input) {
    const identityValue = eventIdentity(input);
    return transaction(() => {
      const sessionRow = readSession(db, identityValue.host, identityValue.sessionId);
      // No row means no explicit attachment. Crucially, do not insert an
      // ignored event here: an unattached prompt/final answer must not enter
      // any durable Trace database merely because a global hook saw it.
      if (!sessionRow) return eventResult({identityValue, session: null, outcome: 'ignored', reason: 'not_attached'});
      // Only an attached session is allowed to normalize (and, for tool
      // events, hash) an official body. This keeps an untracked global hook
      // from doing work on arbitrary tool payloads before it becomes eligible
      // for capture.
      const normalized = normalizedEvent(input, identityValue);
      const previousReceipt = duplicateEvent(db, identityValue, normalized);
      if (previousReceipt) return previousReceipt;
      if (sessionRow.status === 'ended') {
        if (identityValue.eventKind !== 'SessionEnd') fail('HOST_SESSION_ENDED', 'Host session has ended; event was not accepted', 409);
        const result = eventResult({identityValue, session: sessionRow, outcome: 'ignored', reason: 'session_ended'});
        insertEvent(db, identityValue, normalized, 'ignored', result, now());
        return result;
      }
      if (identityValue.eventKind === 'SessionEnd') {
        const timestamp = now();
        db.prepare(`UPDATE host_sessions SET status='ended', ended_at=?, updated_at=?, last_event_at=? WHERE host=? AND session_id=?`).run(timestamp, timestamp, timestamp, identityValue.host, identityValue.sessionId);
        db.prepare(`UPDATE host_turns SET state='interrupted', interrupted_at=?, updated_at=?
          WHERE host=? AND session_id=? AND state='started'`).run(timestamp, timestamp, identityValue.host, identityValue.sessionId);
        const result = eventResult({identityValue, session: {...sessionRow, status: 'ended', ended_at: timestamp, updated_at: timestamp, last_event_at: timestamp}, outcome: 'applied', reason: 'session_ended'});
        insertEvent(db, identityValue, normalized, 'applied', result, timestamp);
        return result;
      }
      if (sessionRow.status === 'paused') return eventResult({identityValue, session: sessionRow, outcome: 'ignored', reason: 'paused'});
      if (['UserPromptSubmit', 'Stop', 'Interrupt'].includes(identityValue.eventKind) && identityValue.turnId === null) fail('INVALID_HOST_EVENT', `${identityValue.eventKind} requires turn_id`);
      const timestamp = now();
      if (identityValue.eventKind === 'SessionStart') {
        db.prepare('UPDATE host_sessions SET updated_at=?, last_event_at=? WHERE host=? AND session_id=?').run(timestamp, timestamp, identityValue.host, identityValue.sessionId);
        const result = eventResult({identityValue, session: {...sessionRow, updated_at: timestamp, last_event_at: timestamp}, outcome: 'applied'});
        insertEvent(db, identityValue, normalized, 'applied', result, timestamp);
        return result;
      }
      if (identityValue.eventKind === 'PreToolUse' || identityValue.eventKind === 'PostToolUse') {
        // Retain only the safe event identity. Native tool input and output
        // remain with Codex/source evidence and never enter web.sqlite.
        db.prepare('UPDATE host_sessions SET updated_at=?, last_event_at=? WHERE host=? AND session_id=?').run(timestamp, timestamp, identityValue.host, identityValue.sessionId);
        const result = eventResult({identityValue, session: {...sessionRow, updated_at: timestamp, last_event_at: timestamp}, outcome: 'applied'});
        insertEvent(db, identityValue, normalized, 'applied', result, timestamp);
        return result;
      }
      const turnId = identityValue.turnId;
      const existingTurn = readTurn(db, identityValue.host, identityValue.sessionId, turnId);
      if (identityValue.eventKind === 'UserPromptSubmit') {
        if (normalized.prompt === null) fail('INVALID_HOST_EVENT', 'UserPromptSubmit requires prompt after explicit attachment');
        const prompt = normalized.prompt;
        if (existingTurn) {
          if (existingTurn.state !== 'started') fail('HOST_EVENT_OUT_OF_ORDER', 'A prompt cannot be appended after a turn was closed', 409);
          if (existingTurn.prompt !== prompt) fail('HOST_TURN_CONFLICT', 'The turn already has a different prompt', 409);
        } else {
          db.prepare(`INSERT INTO host_turns(host,session_id,turn_id,state,prompt,last_assistant_message,started_at,completed_at,interrupted_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)`).run(identityValue.host, identityValue.sessionId, turnId, 'started', prompt, null, timestamp, null, null, timestamp);
        }
        db.prepare('UPDATE host_sessions SET updated_at=?, last_event_at=? WHERE host=? AND session_id=?').run(timestamp, timestamp, identityValue.host, identityValue.sessionId);
        const turn = turnView(readTurn(db, identityValue.host, identityValue.sessionId, turnId));
        const result = eventResult({identityValue, session: {...sessionRow, updated_at: timestamp, last_event_at: timestamp}, outcome: 'applied', turn, capturedFields: ['prompt']});
        insertEvent(db, identityValue, normalized, 'applied', result, timestamp);
        return result;
      }
      if (!existingTurn || existingTurn.state !== 'started') fail('HOST_EVENT_OUT_OF_ORDER', `${identityValue.eventKind} requires an open turn`, 409);
      if (identityValue.eventKind === 'Stop') {
        db.prepare(`UPDATE host_turns SET state='completed', last_assistant_message=?, completed_at=?, updated_at=?
          WHERE host=? AND session_id=? AND turn_id=? AND state='started'`).run(normalized.last_assistant_message, timestamp, timestamp, identityValue.host, identityValue.sessionId, turnId);
        // Stop only schedules bounded asynchronous sensemaking.  The hook never
        // invokes a model and the job/input are committed with this turn so a
        // successful receipt always has one recoverable source boundary.
        const safeEvidence = db.prepare(`SELECT event_kind,tool_use_id,content_sha256,created_at
          FROM host_ingest_events WHERE host=? AND session_id=? AND turn_id=?
          ORDER BY created_at DESC LIMIT 64`).all(identityValue.host, identityValue.sessionId, turnId);
        const relatedFindings = db.prepare(`SELECT finding_id,observation,desired_behavior,status,scope,target_kind
          FROM workflow_findings WHERE host=? AND session_id=? ORDER BY created_at DESC LIMIT 16`).all(identityValue.host, identityValue.sessionId);
        const job = enqueueSensemakingJob(db, {
          host: identityValue.host,
          session_id: identityValue.sessionId,
          turn_id: turnId,
          prompt: existingTurn.prompt,
          last_assistant_message: normalized.last_assistant_message,
          safe_evidence: safeEvidence,
          related_findings: relatedFindings,
        });
        // Keep the stable job identity in the Stop receipt without exposing the
        // prompt/final body through the hook response.
        var sensemakingJobId = job.job_id;
      } else if (identityValue.eventKind === 'Interrupt') {
        db.prepare(`UPDATE host_turns SET state='interrupted', interrupted_at=?, updated_at=?
          WHERE host=? AND session_id=? AND turn_id=? AND state='started'`).run(timestamp, timestamp, identityValue.host, identityValue.sessionId, turnId);
      }
      db.prepare('UPDATE host_sessions SET updated_at=?, last_event_at=? WHERE host=? AND session_id=?').run(timestamp, timestamp, identityValue.host, identityValue.sessionId);
      const turn = turnView(readTurn(db, identityValue.host, identityValue.sessionId, turnId));
      const result = eventResult({identityValue, session: {...sessionRow, updated_at: timestamp, last_event_at: timestamp}, outcome: 'applied', turn, capturedFields: identityValue.eventKind === 'Stop' ? ['last_assistant_message'] : [], extra: sensemakingJobId === undefined ? {} : {sensemaking_job_id: sensemakingJobId}});
      insertEvent(db, identityValue, normalized, 'applied', result, timestamp);
      return result;
    });
  }

  function captureWorkflowFinding(input) {
    const identityValue = commandIdentity(input, 'finding');
    const suppliedTurnId = optionalIdentity(input.turn_id ?? input.turnId, 'turn_id');
    const observation = validText(input.observation, 'observation');
    const desiredBehavior = optionalText(input.desired_behavior ?? input.desiredBehavior, 'desired_behavior');
    const suppliedScopeContract = input.scope_contract ?? input.scopeContract;
    let normalizedScopeContract = null;
    if (suppliedScopeContract !== undefined && suppliedScopeContract !== null) {
      try { normalizedScopeContract = validateScopeContract(suppliedScopeContract); }
      catch (error) { fail('INVALID_SCOPE_CONTRACT', error instanceof Error ? error.message : 'scope contract is invalid'); }
    }
    // Keep the legacy command fingerprint for captures that did not provide a
    // contract. Existing command receipts must remain replayable after this
    // additive migration. New explicit contracts are part of idempotency.
    return transaction(() => {
      const session = readSession(db, identityValue.host, identityValue.sessionId);
      if (!session || session.status === 'ended') fail(session ? 'HOST_SESSION_ENDED' : 'HOST_SESSION_NOT_FOUND', 'A workflow finding requires an attached or paused host session', session ? 409 : 404);
      const turnId = suppliedTurnId ?? db.prepare(`SELECT turn_id FROM host_turns WHERE host=? AND session_id=? AND state='started' ORDER BY updated_at DESC LIMIT 1`).get(identityValue.host, identityValue.sessionId)?.turn_id;
      if (!turnId) fail('HOST_TURN_NOT_FOUND', 'A workflow finding must reference the current open HostTurn', 404);
      const turn = readTurn(db, identityValue.host, identityValue.sessionId, turnId);
      if (!turn) fail('HOST_TURN_NOT_FOUND', 'A workflow finding must reference a captured HostTurn', 404);
      let scopeContract = normalizedScopeContract;
      if (scopeContract !== null) {
        const attachment = scopeContract.attachment_context;
        if (attachment.host !== null && attachment.host !== identityValue.host || attachment.session_id !== null && attachment.session_id !== identityValue.sessionId || attachment.turn_id !== null && attachment.turn_id !== turnId) {
          fail('SCOPE_ATTACHMENT_CONFLICT', 'scope contract attachment context does not match the Host Session/Turn', 409);
        }
        if (attachment.project_ref !== null && session.project_ref !== null && attachment.project_ref !== session.project_ref) fail('SCOPE_ATTACHMENT_CONFLICT', 'scope contract project attachment does not match the Host Session project', 409);
      } else {
        scopeContract = upcastLegacyScope({scope: 'unknown', project_ref: session.project_ref, host: identityValue.host, session_id: identityValue.sessionId, turn_id: turnId, source_refs: [{type: 'host-turn', host: identityValue.host, session_id: identityValue.sessionId, turn_id: turnId}], status: 'captured'});
      }
      const fingerprint = sha(stableHostJson({operation: 'finding', host: identityValue.host, session_id: identityValue.sessionId, turn_id: suppliedTurnId, observation, desired_behavior: desiredBehavior, ...(normalizedScopeContract === null ? {} : {scope_contract: normalizedScopeContract})}));
      const replay = controlReplay(db, identityValue.commandId, fingerprint);
      if (replay) return replay;
      const timestamp = now();
      const findingId = `workflow-finding:${fingerprint.slice(0, 40)}`;
      const existingFinding = db.prepare('SELECT * FROM workflow_findings WHERE finding_id=?').get(findingId);
      if (!existingFinding) {
        const sourceRefs = JSON.stringify([{type: 'host-turn', host: identityValue.host, session_id: identityValue.sessionId, turn_id: turnId}]);
        db.prepare(`INSERT INTO workflow_findings(finding_id,host,session_id,turn_id,observation,desired_behavior,scope,target_kind,status,source_event_key,created_at,finding_kind,origin,source_refs,scope_contract_json)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(findingId, identityValue.host, identityValue.sessionId, turnId, observation, desiredBehavior, 'unknown', 'unresolved', 'captured', null, timestamp, 'captured', 'explicit', sourceRefs, stableHostJson(scopeContract));
      }
      const finding = findingView(db.prepare(`SELECT f.*, s.project_ref AS attached_project_ref
        FROM workflow_findings f LEFT JOIN host_sessions s ON s.host=f.host AND s.session_id=f.session_id
        WHERE f.finding_id=?`).get(findingId));
      return saveControl(db, identityValue, 'finding', fingerprint, commandResult('captured', identityValue, {operation: 'finding', finding}), timestamp);
    });
  }

  function getSession(input) {
    const host = identity(input.host ?? 'codex', 'host', MAX_HOST);
    const sessionId = identity(input.session_id ?? input.sessionId, 'session_id');
    return sessionView(readSession(db, host, sessionId));
  }

  function listSessions({host} = {}) {
    if (host !== undefined) identity(host, 'host', MAX_HOST);
    const rows = host === undefined
      ? db.prepare('SELECT * FROM host_sessions ORDER BY updated_at DESC').all()
      : db.prepare('SELECT * FROM host_sessions WHERE host=? ORDER BY updated_at DESC').all(host);
    return rows.map(sessionView);
  }

  function listTurns({host, session_id: sessionId, sessionId: alternateSessionId} = {}) {
    const resolvedHost = host === undefined ? undefined : identity(host, 'host', MAX_HOST);
    const resolvedSession = sessionId ?? alternateSessionId;
    if (resolvedSession !== undefined) identity(resolvedSession, 'session_id');
    let rows;
    if (resolvedHost === undefined && resolvedSession === undefined) rows = db.prepare('SELECT * FROM host_turns ORDER BY updated_at DESC').all();
    else if (resolvedHost !== undefined && resolvedSession !== undefined) rows = db.prepare('SELECT * FROM host_turns WHERE host=? AND session_id=? ORDER BY updated_at DESC').all(resolvedHost, resolvedSession);
    else if (resolvedHost !== undefined) rows = db.prepare('SELECT * FROM host_turns WHERE host=? ORDER BY updated_at DESC').all(resolvedHost);
    else rows = db.prepare('SELECT * FROM host_turns WHERE session_id=? ORDER BY updated_at DESC').all(resolvedSession);
    return rows.map(turnView);
  }

  function listWorkflowFindings({host, session_id: sessionId, sessionId: alternateSessionId} = {}) {
    const resolvedHost = host === undefined ? undefined : identity(host, 'host', MAX_HOST);
    const resolvedSession = sessionId ?? alternateSessionId;
    if (resolvedSession !== undefined) identity(resolvedSession, 'session_id');
    let rows;
    if (resolvedHost === undefined && resolvedSession === undefined) rows = db.prepare('SELECT f.*, s.project_ref AS attached_project_ref FROM workflow_findings f LEFT JOIN host_sessions s ON s.host=f.host AND s.session_id=f.session_id ORDER BY f.created_at DESC').all();
    else if (resolvedHost !== undefined && resolvedSession !== undefined) rows = db.prepare('SELECT f.*, s.project_ref AS attached_project_ref FROM workflow_findings f LEFT JOIN host_sessions s ON s.host=f.host AND s.session_id=f.session_id WHERE f.host=? AND f.session_id=? ORDER BY f.created_at DESC').all(resolvedHost, resolvedSession);
    else if (resolvedHost !== undefined) rows = db.prepare('SELECT f.*, s.project_ref AS attached_project_ref FROM workflow_findings f LEFT JOIN host_sessions s ON s.host=f.host AND s.session_id=f.session_id WHERE f.host=? ORDER BY f.created_at DESC').all(resolvedHost);
    else rows = db.prepare('SELECT f.*, s.project_ref AS attached_project_ref FROM workflow_findings f LEFT JOIN host_sessions s ON s.host=f.host AND s.session_id=f.session_id WHERE f.session_id=? ORDER BY f.created_at DESC').all(resolvedSession);
    return rows.map(findingView);
  }

  return Object.freeze({
    attach,
    pause,
    detach,
    ingestEvent,
    captureWorkflowFinding,
    getSession,
    listSessions,
    listTurns,
    listWorkflowFindings,
  });
}
